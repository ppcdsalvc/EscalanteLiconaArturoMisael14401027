package mx.edu.ittepic.caso3;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1,b2;
    EditText t1,inicio,fin,creditos;

    private BaseDatos admin;
    private SQLiteDatabase bd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        admin = new BaseDatos(this,"basecaso3", null,1);
        bd = admin.getWritableDatabase();
        t1= (EditText) findViewById(R.id.editText);
        inicio = findViewById(R.id.edtfechai);
        fin = findViewById(R.id.edtfechaf);
        creditos = findViewById(R.id.edtcreditos);

        b1 = (Button) findViewById(R.id.button);
        b2 =(Button) findViewById(R.id.button4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BaseDatos admin = new BaseDatos(MainActivity.this,"basecaso3", null,1);
                bd = admin.getWritableDatabase();
                ContentValues registro = new ContentValues();

                if ( t1!= null) {

                    registro.put("nombre", t1.getText().toString()); // nombre del campo de la tabla
                    registro.put("f_inicio",inicio.getText().toString());
                    registro.put("f_fin", fin.getText().toString());
                    registro.put("creditos", creditos.getText().toString());
                    bd.insert("actividad",null,registro);// la tabla

                    bd.close();
                    Toast.makeText(MainActivity.this, "REGISTRO ALMACENADO", Toast.LENGTH_LONG).show();

                    t1.setText("");


                } else {
                    Toast.makeText(MainActivity.this, "REGISTRO   NO ALMACENADO", Toast.LENGTH_LONG).show();// indica una alerta de que se registro

                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(MainActivity.this,municipio.class);
               startActivity(intent);
            }
        });

    }



}
