package mx.edu.ittepic.caso3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by FABRICAS on 12/03/2018.
 */

public class BaseDatos extends SQLiteOpenHelper {
    public BaseDatos(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(" create table actividad ( idactividad integer primary key autoincrement,nombre text,f_inicio text,f_fin text,creditos text)");
        db.execSQL(" create table alumno( idalumno integer primary key autoincrement,nombre text,cel text,mail text,carrera text,idactividad INTEGER NOT NULL CONSTRAINT fk_id_actividad REFERENCES actividad(idactividad) ON DELETE CASCADE ON UPDATE CASCADE)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists actividad" );
        db.execSQL(" create table actividad ( idactividad integer primary key autoincrement,nombre text)");
        db.execSQL("drop table if exists alumno" );
        db.execSQL(" create table alumno( idalumno integer primary key autoincrement,nombre text,idactividad INTEGER NOT NULL CONSTRAINT fk_id_actividad REFERENCES actividad(idactividad) ON DELETE CASCADE ON UPDATE CASCADE)");


    }
}
